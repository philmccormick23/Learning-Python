import random
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = "shhh"

@app.route('/')
def index():
    if 'gold' not in session:
        session['gold']=0
        


    return render_template('ninjagold.html', goldVal=session['gold'])


@app.route('/process_money', methods=['POST'])
def money():
    if request.form['type']=='farm':
        session['gold'] += random.randrange(10, 20)
        print(session['gold'])
    elif request.form['type']=='cave':
        session['gold'] += random.randrange(5, 10)
        print(session['gold'])
    elif request.form['type']=='house':
        session['gold'] += random.randrange(2, 5)
        print(session['gold'])
    elif request.form['type']=='casino':
        session['gold'] += random.randrange(-50, 50)
        print(session['gold'])
    
    


    return redirect('/')
    

if __name__ == '__main__':
    app.run(debug=True)